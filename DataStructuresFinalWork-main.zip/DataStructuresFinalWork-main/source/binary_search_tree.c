#include "binary_search_tree.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

bst_node* bst_init(){
    return NULL;
    bst_cmp = 0;
    bst_num = 0;
}

bst_node* bst_search(bst_node *root, char* word){
    int c;
    while(root != NULL){
        c = strcmp(word, root->word);
        bst_cmp++;
        if (c == 0){
            bst_cmp++;
            return root;
        }
        else {
            bst_cmp++;
            if (c < 0)
                root = root->left;
            else
                root = root->right;
        }
    }
    return NULL;
}

bst_node* bst_insert(bst_node *root, char* word, char* syn){
    int bst_cmp;
    if (root == NULL){
        bst_num ++;
        root = malloc(sizeof(bst_node));
        strcpy(root->word, word);
        strcpy(root->synonym, syn);
        root->right = NULL;
        root->left = NULL;
    }
    else {
        bst_cmp = strcmp(root->word, word);
        if (bst_cmp < 0)
            root->right = bst_insert(root->right, word, syn);
        else if (bst_cmp > 0)
            root->left = bst_insert(root->left, word, syn);
    }
    return root;
}

void bst_print_inorder_left(bst_node *root){
    if (root != NULL) {
        bst_print_inorder_left(root->left);
        printf("%s\t%s\n", root->word, root->synonym);
        bst_print_inorder_left(root->right);
    }
}

int bst_height(bst_node* a){
    int height_left = 0, height_right = 0;
    
    if (a != NULL){
        height_left = 1 + bst_height(a->left);
        height_right = 1 + bst_height(a->right);

        if (height_left > height_right)
            return height_left;
        return height_right;
    }
    return 0;
}