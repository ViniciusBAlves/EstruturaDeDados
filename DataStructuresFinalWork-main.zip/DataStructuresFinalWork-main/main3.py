import re
from os import path, listdir
from pprint import pprint
from pandas import DataFrame
import numpy as np
import matplotlib.pyplot as plt

pattern = re.compile(r"""Arvore rubro-negra, dict/dict_(\d+)K\.txt$
Palavras lidas: \d+000
Arquivo data/Alienista_cap1_cpy\.txt gerado com sucesso\.
Tempo: \d+\.\d+ ms
ComparaÃ§Ãµes: (\d+)

Arvore binaria de pesquisa, dict/dict_\d+K\.txt$
Palavras lidas: \d+000
Arquivo data/Alienista_cap1_cpy\.txt gerado com sucesso\.
Tempo: \d+\.\d+ ms
ComparaÃ§Ãµes: (\d+)

Arvore rubro-negra, dict_sorted/dict_\d+K_sorted\.txt
Palavras lidas: \d+000
Arquivo data/Alienista_cap1_cpy\.txt gerado com sucesso\.
Tempo: \d+\.\d+ ms
ComparaÃ§Ãµes: (\d+)

Arvore binaria de pesquisa, dict_sorted/dict_\d+K_sorted\.txt$
Palavras lidas: \d+000
Arquivo data/Alienista_cap1_cpy\.txt gerado com sucesso\.
Tempo: \d+\.\d+ ms
ComparaÃ§Ãµes: (\d+)""", re.M)

df = {
    'size': [],
    'rbt-dict': [],
    'bst-dict': [],
    'rbt-sort': [],
    'bst-sort': []
}

files = [f for f in listdir('output') if path.isfile(path.join('output', f))]
files.sort()
buffer = files[0]
for i in range(1,len(files)):
    files[i-1] = files[i]
files[9] = buffer

for file in files:
    with open(path.join('output', file), 'r', encoding="latin-1") as f:
        text = f.read()
        a = pattern.findall(text)[0]

        df['size'].append(int(a[0]))
        df['rbt-dict'].append(int(a[1]))
        df['bst-dict'].append(int(a[2]))
        df['rbt-sort'].append(int(a[3]))
        df['bst-sort'].append(int(a[4]))

        f.close()

title_name = {
    'rbt-dict': 'Árvore rubro-negra (dicionário aleatório)',
    'bst-dict': 'Árvore de pesquisa binária (dicionário aleatório)',
    'rbt-sort': 'Árvore rubro-negra (dicionario ordenado)',
    'bst-sort': 'Árvore de pesquisa binária (dicionário ordenado)'
}

rbt_dict = np.array(df['rbt-dict'])
bst_dict = np.array(df['bst-dict'])
rbt_sort = np.array(df['rbt-sort'])
bst_sort = np.array(df['bst-sort'])

x = np.array(df['size'])

for tree in title_name.keys():
    plt.style.use('ggplot')
    plt.title(f'''Número de comparações em uma 
    {title_name[tree]} 
    em função do tamanho do dicionário''')

    plt.subplots_adjust(top=0.8)

    plt.xlabel('Palavras no dicionário (em mil palavras)') 
    plt.ylabel('Número de comparações')

    plt.bar(x, np.array(df[tree]), color='#7c8c9c')
    plt.savefig('out-'+tree.lower()+'.png')

    plt.cla()
    plt.clf()

df = DataFrame(df)
df.to_excel(excel_writer='out-trees.xlsx', index=False)
