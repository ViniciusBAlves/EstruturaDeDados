#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <time.h>
#include <ctype.h>
#include "source/red_black_tree.h"

void ToLower(char *p) {
    while(*p) {
        *p = tolower(*p);
        p ++;
    }
}

#define SIZELINE 1024
#define SIZEWORD 64

int main(int argc, char **argv){
    setlocale(LC_ALL, "pt_BR");

    rbt_node *rbt_root, *rbt_node = NULL;

    FILE* file, *input, *output;

    char line[SIZELINE], sep[] = {" ,.&*%\?!;/'@\"$#=><()][}{:\n\t"};
    char *str, *syn, dict_name[] = {"data/dict_10K.txt"};
    char file_name[SIZELINE], output_name[SIZELINE], ch;
    char data_output[SIZELINE];
    int height, i;
    float miliseconds;
    clock_t start, end;

    /* 
     * pelo menos o arquivo de entrada e de saida devem ser passados
     * pode ser passado tambem o dicionario utilizado
     * caso ele nao seja passado, entao sera utilizado o dicionario padrao
    */

    if (argc != 3){
        printf ("Número inválido de argumentos");
        return 1;
    }
    
    rbt_root = rbt_init();

    // abre o dicionario utilizado
    if (!(file = fopen(argv[2], "r"))) {
        printf ("Erro ao abrir o arquivo %s",argv[2]);
        return 1;
    }

    /* 
     * para cada linha cria um nodo com a primeira 
     * palavra e coloca a segunda palavra como 
     * sinonimo da primeira, entao incrementa
     * o numero de palavras contabilizadas
    */

    while (fgets(line, SIZELINE, file)) {
        str = strtok (line, sep); 
        syn = strtok (NULL, sep);
        ToLower(str);
        ToLower(syn);
        rbt_root = rbt_insert(rbt_root, str, syn);
    }

    // abre o arquivo de entrada
    if (!(input = fopen (argv[1], "r"))) {
        printf ("Erro ao abrir o arquivo %s",argv[1]);
        return 1;
    }

    // remove a extensao do arquivo de entrada
    strcpy(file_name, argv[1]);
    i = strlen(file_name);
    while (file_name[i] != '.' && i > 0){
        file_name[i] = '\0';
        i --;
    }
    if (i != 0)
        file_name[i] = '\0'; // apaga o '.'
    else
        strcpy(file_name, argv[1]); // arquivo sem extensao
    
    // nomeia os arquivos de saida 
    strcpy(output_name, file_name);
    strcat(output_name, "_parafraseado.txt");
    strcpy(data_output, file_name);
    strcat(data_output, "_dados.txt");

    
    strcpy(data_output, "rbt_");
    strcat(data_output, argv[2]);
    for (i = 0; i < strlen(data_output); i ++)
        if (data_output[i] == '/')
            data_output[i] = '_';        
    

    // abre o arquivo de saida
    if (!(output = fopen (output_name, "w"))) {
        printf ("Erro ao abrir o arquivo %s", output_name);
        return 1;
    }

    start = clock(); 

    //percorre todo o arquivo lendo linha por linha
    while (fgets(line,SIZELINE,input)) {
        str = strtok (line, sep); 
        while (str != NULL) {
            ToLower(str);
            if (rbt_node = rbt_search(rbt_root, str)){
                fprintf(output,"%s ", rbt_node->synonym);
            }
            else
                fprintf(output,"%s ", str);
            str = strtok (NULL, sep);
        }
    }

    fclose(file);
    fclose(input);
    fclose(output);

    printf("Arquivo %s gerado com sucesso.\n", output_name);

    // finaliza, calcula e exibe a contagem do tempo e das comparacoes

    end = clock();
    miliseconds = (float)(end - start) / CLOCKS_PER_SEC * 1000; 
    height = rbt_height(rbt_root);

    // abre o arquivo de saida de dados
    if (!(output = fopen (data_output, "w"))) {
        printf ("Erro ao abrir o arquivo %s",data_output);
        return 1;
    }

    fprintf(output, "Arvore rubro negra, %s\n", argv[2]);
    fprintf(output, "Palavras lidas: %d\n", rbt_num);
    fprintf(output, "Tempo: %.5f ms\n", miliseconds);
    fprintf(output, "Comparações: %d\n", rbt_cmp);
    fprintf(output, "Rotações: %d\n", rbt_rot);
    fprintf(output, "Altura: %d\n\n", height);

    return 0;
}