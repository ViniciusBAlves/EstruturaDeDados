import matplotlib.pyplot as plt
import pandas as pd
file = 'rbt_10K_sort.csv'
data = pd.read_csv(file).to_dict('list')
plt.bar(data['size'], data['cmp'])
plt.show()