#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <time.h>
#include <ctype.h>
#include "source/red_black_tree.h"
#include "source/binary_search_tree.h"

void ToLower(char *p) {
    while(*p) {
        *p = tolower(*p);
        p ++;
    }
}

#define SIZELINE 1024
#define SIZEWORD 64

int main(int argc, char **argv){
    setlocale(LC_ALL, "pt_BR");

    bst_node *bst_root, *bst_node = NULL;
    rbt_node *rbt_root, *rbt_node = NULL;

    FILE* file, *input, *output;

    char line[SIZELINE], sep[] = {" ,.&*%\?!;/'@\"$#=><()][}{:\n\t"};
    char *str, *syn, dict_name[] = {"data/dict_10K.txt"};
    char dict_sorted[] = {"data/dict_10K_sorted.txt"};
    int num=0;

    strcpy(dict_name, argv[3]);
    strcpy(dict_sorted, argv[4]);

    float miliseconds;

    clock_t start, end;

    //   EXECUCAO RED BLACK TREE
    printf("Arvore rubro-negra, %s\n", dict_name);

    num = 0;
    
    /*
     * argumentos esperados: 
     *      endereco do arquivo de entrada,
     *      endereco do arquivo de saida
    */
    /*if (argc != 5) {
        printf ("Número inválido de argumentos");
        return 1;
    }*/

    rbt_root = rbt_init();

    // abre o dicionario utilizado
    if (!(file = fopen(dict_name, "r"))) {
        printf ("Erro ao abrir o arquivo %s",dict_name);
        return 1;
    }

    /* 
     * para cada linha cria um nodo com a primeira 
     * palavra e coloca a segunda palavra como 
     * sinonimo da primeira, entao incrementa
     * o numero de palavras contabilizadas
    */

    while (fgets(line, SIZELINE, file)) {
        str = strtok (line, sep); 
        syn = strtok (NULL, sep);
        ToLower(str);
        ToLower(syn);
        rbt_root = rbt_insert(rbt_root, str, syn);
        num ++;
    }

    printf("Palavras lidas: %d\n", num);

    // abre o arquivo de entrada
    if (!(input = fopen (argv[1], "r"))) {
        printf ("Erro ao abrir o arquivo %s",argv[1]);
        return 1;
    }

    // abre o arquivo de saida
    if (!(output = fopen (argv[2], "w"))) {
        printf ("Erro ao abrir o arquivo %s",argv[2]);
        return 1;
    }

    start = clock(); 
    cmp = 0;

    //percorre todo o arquivo lendo linha por linha
    while (fgets(line,SIZELINE,input)) {
        str = strtok (line, sep); 
        while (str != NULL) {
            ToLower(str);
            if (rbt_node = rbt_search(rbt_root, str)){
                fprintf(output,"%s ", rbt_node->synonym);
            }
            else
                fprintf(output,"%s ", str);
            str = strtok (NULL, sep);
        }
        fprintf(output,"\n");
    }

    printf("Arquivo %s gerado com sucesso.\n",argv[2]);

    // finaliza, calcula e exibe a contagem do tempo e das comparacoes

    end = clock();
    miliseconds = (float)(end - start) / CLOCKS_PER_SEC * 1000; 
    printf("Tempo: %.5f ms\n",miliseconds);
    printf("Comparações: %d\n", cmp);
    printf("Rotações: %d\n\n", rot);

    fclose (input);
    fclose (output);

    //   EXECUCAO BINARY SEARCH TREE 
    printf("Arvore binaria de pesquisa, %s\n", dict_name);

    num = 0;

    bst_root = bst_init();

    // abre o dicionario utilizado
    if (!(file = fopen(dict_name, "r"))) {
        printf ("Erro ao abrir o arquivo %s",dict_name);
        return 1;
    }

    /* 
     * para cada linha cria um nodo com a primeira 
     * palavra e coloca a segunda palavra como 
     * sinonimo da primeira, entao incrementa
     * o numero de palavras contabilizadas
    */

    while (fgets(line, SIZELINE, file)) {
        str = strtok (line, sep); 
        syn = strtok (NULL, sep);
        ToLower(str);
        ToLower(syn);
        bst_root = bst_insert(bst_root, str, syn);
        num ++;
    }

    printf("Palavras lidas: %d\n", num);

    // abre o arquivo de entrada
    if (!(input = fopen (argv[1], "r"))) {
        printf ("Erro ao abrir o arquivo %s",argv[1]);
        return 1;
    }

    // abre o arquivo de saida
    if (!(output = fopen (argv[2], "w"))) {
        printf ("Erro ao abrir o arquivo %s",argv[2]);
        return 1;
    }

    // inicia a contagem do tempo, das comparacoes e do numero de palavras
    start = clock(); 
    cmp = 0; 

    /* 
     * percorre todo o arquivo lendo linha por linha
     * para cada palavra da linha, verifica se ela existe
     * no dicionario armazenado na arvore, caso exista
     * ela e substituida pelo seu sinonimo no arquivo de saida, 
     * caso contrario ela e copiada para o arquivo de saida 
    */

    while (fgets(line,SIZELINE,input)) {
        
        str = strtok (line, sep);
        while (str != NULL) {
            ToLower(str);
            if (bst_node = bst_search(bst_root, str)){
                fprintf(output,"%s ", bst_node->synonym);
            }
            else
                fprintf(output,"%s ", str);
            str = strtok (NULL, sep);
        }
        fprintf(output,"\n");
    }

    printf("Arquivo %s gerado com sucesso.\n",argv[2]);

    // finaliza, calcula e exibe a contagem do tempo e das comparacoes
    end = clock(); 
    miliseconds = (float)(end - start) / CLOCKS_PER_SEC * 1000; //calcula o tempo decorrido
    printf("Tempo: %.5f ms\n",miliseconds);
    printf("Comparações: %d\n\n", cmp);

    fclose (input);
    fclose (output);


    /* SORTED DICTIONARY */

    printf("Arvore rubro-negra, %s\n", dict_sorted);

    //   EXECUCAO RED BLACK TREE
    
    /*
     * argumentos esperados: 
     *      endereco do arquivo de entrada,
     *      endereco do arquivo de saida
    */
    
    num = 0;

    rbt_root = rbt_init();

    // abre o dicionario utilizado
    if (!(file = fopen(dict_sorted, "r"))) {
        printf ("Erro ao abrir o arquivo %s", dict_sorted);
        return 1;
    }

    /* 
     * para cada linha cria um nodo com a primeira 
     * palavra e coloca a segunda palavra como 
     * sinonimo da primeira, entao incrementa
     * o numero de palavras contabilizadas
    */

    while (fgets(line, SIZELINE, file)) {
        str = strtok (line, sep); 
        syn = strtok (NULL, sep);
        ToLower(str);
        ToLower(syn);
        rbt_root = rbt_insert(rbt_root, str, syn);
        num ++;
    }

    printf("Palavras lidas: %d\n", num);

    // abre o arquivo de entrada
    if (!(input = fopen (argv[1], "r"))) {
        printf ("Erro ao abrir o arquivo %s",argv[1]);
        return 1;
    }

    // abre o arquivo de saida
    if (!(output = fopen (argv[2], "w"))) {
        printf ("Erro ao abrir o arquivo %s",argv[2]);
        return 1;
    }

    start = clock(); 
    cmp = 0;

    //percorre todo o arquivo lendo linha por linha
    while (fgets(line,SIZELINE,input)) {
        str = strtok (line, sep); 
        while (str != NULL) {
            ToLower(str);
            if (rbt_node = rbt_search(rbt_root, str)){
                fprintf(output,"%s ", rbt_node->synonym);
            }
            else
                fprintf(output,"%s ", str);
            str = strtok (NULL, sep);
        }
        fprintf(output,"\n");
    }

    printf("Arquivo %s gerado com sucesso.\n",argv[2]);

    // finaliza, calcula e exibe a contagem do tempo e das comparacoes

    end = clock();
    miliseconds = (float)(end - start) / CLOCKS_PER_SEC * 1000; 
    printf("Tempo: %.5f ms\n",miliseconds);
    printf("Comparações: %d\n", cmp);
    printf("Rotações: %d\n\n", rot);

    fclose (input);
    fclose (output);

    //   EXECUCAO BINARY SEARCH TREE 
    printf("Arvore binaria de pesquisa, %s\n", dict_sorted);

    num = 0;

    bst_root = bst_init();

    // abre o dicionario utilizado
    if (!(file = fopen(dict_sorted, "r"))) {
        printf ("Erro ao abrir o arquivo %s",dict_sorted);
        return 1;
    }

    /* 
     * para cada linha cria um nodo com a primeira 
     * palavra e coloca a segunda palavra como 
     * sinonimo da primeira, entao incrementa
     * o numero de palavras contabilizadas
    */

    while (fgets(line, SIZELINE, file)) {
        str = strtok (line, sep); 
        syn = strtok (NULL, sep);
        ToLower(str);
        ToLower(syn);
        bst_root = bst_insert(bst_root, str, syn);
        num ++;
    }

    printf("Palavras lidas: %d\n", num);

    // abre o arquivo de entrada
    if (!(input = fopen (argv[1], "r"))) {
        printf ("Erro ao abrir o arquivo %s",argv[1]);
        return 1;
    }

    // abre o arquivo de saida
    if (!(output = fopen (argv[2], "w"))) {
        printf ("Erro ao abrir o arquivo %s",argv[2]);
        return 1;
    }

    // inicia a contagem do tempo, das comparacoes e do numero de palavras
    start = clock(); 
    cmp = 0; 

    /* 
     * percorre todo o arquivo lendo linha por linha
     * para cada palavra da linha, verifica se ela existe
     * no dicionario armazenado na arvore, caso exista
     * ela e substituida pelo seu sinonimo no arquivo de saida, 
     * caso contrario ela e copiada para o arquivo de saida 
    */

    while (fgets(line,SIZELINE,input)) {
        
        str = strtok (line, sep);
        while (str != NULL) {
            ToLower(str);
            if (bst_node = bst_search(bst_root, str)){
                fprintf(output,"%s ", bst_node->synonym);
            }
            else
                fprintf(output,"%s ", str);
            str = strtok (NULL, sep);
        }
        fprintf(output,"\n");
    }

    printf("Arquivo %s gerado com sucesso.\n",argv[2]);

    // finaliza, calcula e exibe a contagem do tempo e das comparacoes
    end = clock(); 
    miliseconds = (float)(end - start) / CLOCKS_PER_SEC * 1000; //calcula o tempo decorrido
    printf("Tempo: %.5f ms\n",miliseconds);
    printf("Comparações: %d\n\n", cmp);

    fclose (input);
    fclose (output);

    printf("\n\n\n");

    return 0;
}
