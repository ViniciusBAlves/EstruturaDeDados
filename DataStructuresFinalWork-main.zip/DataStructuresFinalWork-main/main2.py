from pprint import pprint
import os
from os import listdir, path

dict_path = 'dict/'
dict_sorted_path = 'dict_sorted/'

dicts = [f for f in listdir(dict_path) if path.isfile(path.join(dict_path, f))]
dicts_sorted = [f for f in listdir(dict_sorted_path) if path.isfile(path.join(dict_sorted_path, f))]

dicts.sort()
dicts_sorted.sort()

data = []

for i in range(len(dicts)):
    data.append((dicts[i], dicts_sorted[i]))

for d1, d2 in data:
    os.system(f"./out data/Alienista_cap1.txt dict/{d1} dict_sorted/{d2}")