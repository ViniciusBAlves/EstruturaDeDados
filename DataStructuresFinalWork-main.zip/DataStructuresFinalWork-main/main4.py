import re
from pprint import pprint
from pandas import DataFrame

file = 'output/out_dict_10K.txt'

pattern = re.compile(r"""Arvore rubro-negra, dict/dict_\d+K\.txt$
Palavras lidas: \d+000
Arquivo data/Alienista_cap1_cpy\.txt gerado com sucesso\.
Tempo: \d+\.\d+ ms
Comparações: (\d+)

Arvore binaria de pesquisa, dict/dict_\d+K\.txt$
Palavras lidas: \d+000
Arquivo data/Alienista_cap1_cpy\.txt gerado com sucesso\.
Tempo: \d+\.\d+ ms
Comparações: (\d+)

Arvore rubro-negra, dict_sorted/dict_\d+K_sorted\.txt
Palavras lidas: \d+000
Arquivo data/Alienista_cap1_cpy\.txt gerado com sucesso\.
Tempo: \d+\.\d+ ms
Comparações: (\d+)

Arvore binaria de pesquisa, dict_sorted/dict_\d+K_sorted\.txt$
Palavras lidas: \d+000
Arquivo data/Alienista_cap1_cpy\.txt gerado com sucesso\.
Tempo: \d+\.\d+ ms
Comparações: (\d+)""", re.M)

df_keys = ['rbt-dict', 'bst-dict', 'rbt-sort', 'bst-sort']
df = {}
for i, key in enumerate(df_keys):
    df[key] = []

with open(file) as f:
    txt = f.read()
    a = pattern.findall(txt)[0]
    for i, key in enumerate(df_keys):
        df[key].append(int(a[i]))
    f.close()
df = DataFrame(df)
print(df)