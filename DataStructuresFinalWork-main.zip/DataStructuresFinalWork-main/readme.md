# Gerador de paráfrases
## Trabalho final estrutura de dados

O código a seguir faz uma implementação de diferentes estruturas de árvores de pesquisa. A árvores utilizadas são a árvore de pesquisa binária (binary search tree / BST) e a árvore rubro-negra (red-black tree / RBT). 

As árvores serão desenvolvidas para realizar a substituição de palavras em um texto pelo respectivo sinônimo.

Nessa implementação, a chave de comparação utilizada é uma palavra, que é comparada de modo a ordenar de forma lexicográfica as palavras.

Cada nó da árvore possui os seguintes campos:

 * palavra;
 * sinônimo;
 * ponteiro para o nó pai (para árvore rubro-negra);
 * ponteiro para o nó filho esquerdo;
 * ponteiro para o nó filho direito;
 * cor (para árvore rubro-negra).

## Funções árvore binária de pesquisa

### ```bst_node* bst_init()```
Inicializa uma árvore binária de pesquisa.

### ```bst_node* bst_search(bst_node *root, char word[])```
Busca um nó em uma árvore binária de pesquisa. Caso a palavra buscada não exista na árvore, o retorno é um ponteiro _`NULL`_.

### ```bst_node* bst_insert(bst_node *root, char word[], char synonym[])```
Insere um nó em uma árvore rubro-negra. Caso a palavra já exista na árvore, a árvore é retornada sem alterações. 

## Funções árvore rubro-negra

### ```rbt_node* rbt_init()```
Inicializa uma árvore rubro-negra.

### ```rbt_node* rbt_search(rbt_node *root, char word[])```
Busca um nó em uma árvore rubro-negra. Caso a palavra buscada não exista na árvore, o retorno é um ponteiro _`NULL`_.

### ```rbt_node* rbt_insert(rbt_node *root, char word[], char synonym[])```
Insere um nó em uma árvore rubro-negra. Caso a palavra já exista na árvore, a árvore é retornada sem alterações. Ao fim da inserção, é chamada a função _`rbt_insert_fixup`_.

### ```rbt_node* rbt_insert_fixup(rbt_node *root, rbt_node *z)```
Realiza as rotações e alterações de cores necessárias para manter as características das árvores rubro-negras.

### ```rbt_node* rbt_left_rotate(rbt_node *root, rbt_node *z);```
Realiza uma rotação à esquerda na árvore.

### ```rbt_node* rbt_right_rotate(rbt_node *root, rbt_node *z);```
Realiza uma rotação à direita na árvore.

