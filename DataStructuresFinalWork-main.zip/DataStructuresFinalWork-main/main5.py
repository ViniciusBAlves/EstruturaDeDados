from pprint import pprint
import os
from os import listdir, path

dict_path = 'dict/'
exe = 'rbt.out'

dicts = [f for f in listdir(dict_path) if path.isfile(path.join(dict_path, f))]

for d in dicts:
    os.system(f"./{exe} data/Alienista_cap1.txt {path.join(dict_path, d)}")