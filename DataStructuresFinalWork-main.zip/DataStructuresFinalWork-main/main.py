for size in range(1000,10001,1000):
    out = open('dict/dict_' + str(size//1000) + 'K.txt', 'w', encoding="latin-1")
    with open('data/dict_10K.txt', 'r', encoding="latin-1") as f:
        for i in range(0, size):
            line = f.readline()
            out.write(line)
        f.close()
    out.close()

for size in range(1000,10001,1000):
    out = open('dict_sorted/dict_' + str(size//1000) + 'K_sorted.txt', 'w', encoding="latin-1")
    with open('data/dict_10K_sorted.txt', 'r', encoding="latin-1") as f:
        for i in range(0, size):
            line = f.readline()
            out.write(line)
        f.close()
    out.close()
