import re
from os import path, listdir

pattern_bst_sort = re.compile(r"""Arvore binaria de pesquisa, dict_sorted/dict_(\d+)K_sorted\.txt$
Palavras lidas: \d+000
Tempo: \d+\.\d+ ms
Comparações: (\d+)
Altura: (\d+)""", re.M)

pattern_bst_dict = re.compile(r"""Arvore binaria de pesquisa, dict/dict_(\d+)K\.txt$
Palavras lidas: \d+000
Tempo: \d+\.\d+ ms
Comparações: (\d+)
Altura: (\d+)""", re.M)

pattern_rbt_sort = re.compile(r"""Arvore rubro negra, dict_sorted/dict_(\d+)K_sorted\.txt$
Palavras lidas: \d+000
Tempo: \d+\.\d+ ms
Comparações: (\d+)
Rotações: (\d+)
Altura: (\d+)""", re.M)

pattern_rbt_dict = re.compile(r"""Arvore rubro negra, dict/dict_(\d+)K\.txt$
Palavras lidas: \d+000
Tempo: \d+\.\d+ ms
Comparações: (\d+)
Rotações: (\d+)
Altura: (\d+)""", re.M)


_path = 'rbt_dict'
files = [f for f in listdir(_path) if path.isfile(path.join(_path, f))]

files.sort()

buffer = files[0]
for i in range(1,len(files)):
    files[i-1] = files[i]
files[len(files) - 1] = buffer

with open('rbt_10K_dict.csv', 'w') as dt:
    dt.write('size,cmp,height,rotate\n')
    for file in files:
        f = open(path.join(_path, file), 'r')
        txt = f.read()
        a = pattern_rbt_dict.findall(txt)[0]
        dt.write(a[0]+','+a[1]+','+a[2]+','+a[3]+'\n')
        f.close()
    dt.close()
    